let tarefas = [
  {
    nome: 'Comprar leite',
    categoria: 'compras',
    marcado: false
  },
  {
    nome: 'Escutar chimbinha',
    categoria: 'lazer',
    marcado: true
  }
];

// Exercício 1: carregar as tarefas existentes
// ------------
//




// Exercício 2: incluir uma nova tarefa
// -----------
//


  